package org.example.reportsworskhopgft.eventlog.domain;

public enum EventType {
    // Time
    TIME_ADVANCED,

    // Transport
    DELIVERY_CREATED,
    TRUCK_REGISTERED,
    TRUCK_STATUS_CHANGED,
    TRUCK_POSITION_UPDATE,

    // Production
    RECIPE_REGISTERED,
    PRODUCTION_ORDER_CREATED,
    PRODUCTION_ORDER_STARTED,
    PRODUCTION_ORDER_BLOCKED,
    PRODUCTION_ORDER_COMPLETED,

    // Warehouse
    REPLENISHMENT_REQUESTED,
    WAREHOUSE_STOCK_CHANGED
}